"""
DomainInsight - DNS Lookup
Retrieves DNS records for domains
"""

import dns.resolver
import dns.exception

class DNSLookup:
    """DNS records retrieval"""
    
    def __init__(self):
        self.resolver = dns.resolver.Resolver()
        self.resolver.timeout = 5.0
        self.resolver.lifetime = 5.0
    
    def get_dns_records(self, domain):
        """
        Get DNS records for a domain
        
        Args:
            domain (str): The domain to look up
        
        Returns:
            dict: DNS records
        """
        results = {
            'domain': domain
        }
        
        # Get A records
        results['a'] = self._get_a_records(domain)
        
        # Get AAAA records
        results['aaaa'] = self._get_aaaa_records(domain)
        
        # Get MX records
        results['mx'] = self._get_mx_records(domain)
        
        # Get NS records
        results['ns'] = self._get_ns_records(domain)
        
        # Get TXT records
        results['txt'] = self._get_txt_records(domain)
        
        # Get CNAME records
        results['cname'] = self._get_cname_records(domain)
        
        # Get SOA record
        results['soa'] = self._get_soa_record(domain)
        
        # Check for DNSSEC
        results['dnssec'] = self._check_dnssec(domain)
        
        # Check for SPF record
        results['has_spf'] = self._check_spf(domain, results['txt'])
        
        # Check for DMARC record
        results['has_dmarc'] = self._check_dmarc(domain, results['txt'])
        
        return results
    
    def _get_a_records(self, domain):
        """Get A records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'A')
            return [str(rdata) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_aaaa_records(self, domain):
        """Get AAAA records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'AAAA')
            return [str(rdata) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_mx_records(self, domain):
        """Get MX records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'MX')
            mx_records = []
            
            for rdata in answers:
                mx_records.append({
                    'priority': rdata.preference,
                    'host': str(rdata.exchange)
                })
            
            return mx_records
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_ns_records(self, domain):
        """Get NS records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'NS')
            return [str(rdata) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_txt_records(self, domain):
        """Get TXT records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'TXT')
            return [str(rdata).strip('"') for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_cname_records(self, domain):
        """Get CNAME records for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'CNAME')
            return [str(rdata) for rdata in answers]
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return []
    
    def _get_soa_record(self, domain):
        """Get SOA record for a domain"""
        try:
            answers = self.resolver.resolve(domain, 'SOA')
            
            for rdata in answers:
                return {
                    'mname': str(rdata.mname),
                    'rname': str(rdata.rname),
                    'serial': rdata.serial,
                    'refresh': rdata.refresh,
                    'retry': rdata.retry,
                    'expire': rdata.expire,
                    'minimum': rdata.minimum
                }
            
            return {}
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return {}
    
    def _check_dnssec(self, domain):
        """Check if DNSSEC is enabled for a domain"""
        try:
            # Try to get DNSKEY records
            self.resolver.resolve(domain, 'DNSKEY')
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            # Try to get DS records from parent zone
            try:
                parent_domain = '.'.join(domain.split('.')[1:])
                if parent_domain:
                    self.resolver.resolve(domain, 'DS')
                    return True
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
                pass
            
            return False
    
    def _check_spf(self, domain, txt_records):
        """Check if domain has an SPF record"""
        # Check TXT records for SPF
        for record in txt_records:
            if record.startswith('v=spf1'):
                return True
        
        # Check for SPF type record (deprecated but still used)
        try:
            self.resolver.resolve(domain, 'SPF')
            return True
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return False
    
    def _check_dmarc(self, domain, txt_records):
        """Check if domain has a DMARC record"""
        dmarc_domain = f"_dmarc.{domain}"
        
        try:
            answers = self.resolver.resolve(dmarc_domain, 'TXT')
            
            for rdata in answers:
                record = str(rdata).strip('"')
                if record.startswith('v=DMARC1'):
                    return True
            
            return False
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.DNSException):
            return False
