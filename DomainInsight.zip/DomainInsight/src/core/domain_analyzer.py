"""
DomainInsight - Domain Analyzer
Core functionality for domain analysis
"""

import time
from .whois_lookup import WhoisLookup
from .dns_lookup import DNSLookup
from .history_lookup import HistoryLookup
from .related_lookup import RelatedLookup

class DomainAnalyzer:
    """Main domain analysis engine"""
    
    def __init__(self):
        self.whois_lookup = WhoisLookup()
        self.dns_lookup = DNSLookup()
        self.history_lookup = HistoryLookup()
        self.related_lookup = RelatedLookup()
    
    def analyze_domain(self, domain, progress_callback=None):
        """
        Analyze a domain and gather comprehensive information
        
        Args:
            domain (str): The domain to analyze
            progress_callback (callable): Optional callback for progress updates
                Function signature: callback(progress_percent, message)
        
        Returns:
            dict: Analysis results
        """
        results = {
            'domain': domain,
            'analysis_time': time.time()
        }
        
        # Update progress
        if progress_callback:
            progress_callback(10, "Looking up WHOIS information...")
        
        # Get WHOIS information
        whois_info = self.whois_lookup.get_whois(domain)
        results['whois'] = whois_info
        
        # Update progress
        if progress_callback:
            progress_callback(30, "Looking up DNS records...")
        
        # Get DNS records
        dns_records = self.dns_lookup.get_dns_records(domain)
        results['dns'] = dns_records
        
        # Update progress
        if progress_callback:
            progress_callback(50, "Retrieving hosting history...")
        
        # Get hosting history
        hosting_history = self.history_lookup.get_history(domain)
        results['history'] = hosting_history
        
        # Update progress
        if progress_callback:
            progress_callback(70, "Finding related domains...")
        
        # Get related domains
        related_domains = self.related_lookup.find_related(domain, whois_info)
        results['related'] = related_domains
        
        # Calculate security score
        results['security_score'] = self._calculate_security_score(results)
        
        # Update progress
        if progress_callback:
            progress_callback(90, "Finalizing analysis...")
        
        # Add summary information
        results['summary'] = self._generate_summary(results)
        
        # Final progress update
        if progress_callback:
            progress_callback(100, "Analysis complete")
        
        return results
    
    def _calculate_security_score(self, results):
        """Calculate a security score based on analysis results"""
        score = 100  # Start with perfect score
        reasons = []
        
        # Check WHOIS privacy
        if results['whois'].get('privacy_protection') == False:
            score -= 10
            reasons.append("No WHOIS privacy protection")
        
        # Check domain age
        if results['whois'].get('age_days', 0) < 30:
            score -= 20
            reasons.append("Domain is less than 30 days old")
        elif results['whois'].get('age_days', 0) < 90:
            score -= 10
            reasons.append("Domain is less than 90 days old")
        
        # Check DNS security
        dns = results['dns']
        
        # Check for DNSSEC
        if not dns.get('dnssec', False):
            score -= 10
            reasons.append("DNSSEC not enabled")
        
        # Check for SPF
        if not dns.get('has_spf', False):
            score -= 5
            reasons.append("SPF record missing")
        
        # Check for DMARC
        if not dns.get('has_dmarc', False):
            score -= 5
            reasons.append("DMARC record missing")
        
        # Check for MX records
        if not dns.get('mx', []):
            score -= 5
            reasons.append("No MX records found")
        
        # Limit score to 0-100 range
        score = max(0, min(100, score))
        
        return {
            'score': score,
            'reasons': reasons
        }
    
    def _generate_summary(self, results):
        """Generate a summary of the analysis results"""
        summary = {}
        
        # Domain information
        summary['domain'] = results['domain']
        
        # WHOIS summary
        whois = results['whois']
        summary['registrar'] = whois.get('registrar', 'Unknown')
        summary['creation_date'] = whois.get('creation_date', 'Unknown')
        summary['expiration_date'] = whois.get('expiration_date', 'Unknown')
        summary['age_days'] = whois.get('age_days', 0)
        
        # DNS summary
        dns = results['dns']
        summary['ip_address'] = dns.get('a', ['Unknown'])[0] if dns.get('a') else 'Unknown'
        summary['nameservers'] = len(dns.get('ns', []))
        
        # History summary
        history = results['history']
        summary['ip_changes'] = history.get('ip_changes', 0)
        summary['nameserver_changes'] = history.get('nameserver_changes', 0)
        
        # Related domains summary
        related = results['related']
        summary['subdomains'] = len(related.get('subdomains', []))
        summary['similar_domains'] = len(related.get('similar', []))
        
        # Security score
        summary['security_score'] = results['security_score']['score']
        
        return summary
