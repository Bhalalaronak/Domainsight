"""
DomainInsight - WHOIS Lookup
Retrieves WHOIS information for domains
"""

import whois
import datetime
import os
import requests
from dotenv import load_dotenv

class WhoisLookup:
    """WHOIS information retrieval"""
    
    def __init__(self):
        load_dotenv()
        self.api_key = os.getenv("WHOISXMLAPI_KEY")
    
    def get_whois(self, domain):
        """
        Get WHOIS information for a domain
        
        Args:
            domain (str): The domain to look up
        
        Returns:
            dict: WHOIS information
        """
        whois_info = {}
        
        try:
            # Try using python-whois library first
            w = whois.whois(domain)
            
            # Extract relevant information
            whois_info = self._extract_whois_data(w)
            
            # If we have an API key, enhance with additional data
            if self.api_key and (not whois_info or not whois_info.get('registrar')):
                api_data = self._get_whois_from_api(domain)
                if api_data:
                    # Merge data, preferring API data for missing fields
                    for key, value in api_data.items():
                        if key not in whois_info or not whois_info[key]:
                            whois_info[key] = value
        
        except Exception as e:
            whois_info['error'] = str(e)
        
        return whois_info
    
    def _extract_whois_data(self, whois_obj):
        """Extract and normalize WHOIS data from python-whois object"""
        data = {}
        
        # Basic information
        data['domain_name'] = self._get_first_value(whois_obj.get('domain_name'))
        data['registrar'] = self._get_first_value(whois_obj.get('registrar'))
        data['whois_server'] = self._get_first_value(whois_obj.get('whois_server'))
        
        # Dates
        creation_date = self._get_first_value(whois_obj.get('creation_date'))
        expiration_date = self._get_first_value(whois_obj.get('expiration_date'))
        updated_date = self._get_first_value(whois_obj.get('updated_date'))
        
        data['creation_date'] = self._format_date(creation_date)
        data['expiration_date'] = self._format_date(expiration_date)
        data['updated_date'] = self._format_date(updated_date)
        
        # Calculate age in days
        if creation_date:
            try:
                if isinstance(creation_date, str):
                    creation_date = datetime.datetime.strptime(creation_date, "%Y-%m-%d")
                
                age_days = (datetime.datetime.now() - creation_date).days
                data['age_days'] = age_days
            except:
                data['age_days'] = 0
        
        # Status
        data['status'] = whois_obj.get('status', [])
        
        # Name servers
        data['name_servers'] = whois_obj.get('name_servers', [])
        
        # Registrant information
        registrant = {}
        
        registrant['name'] = self._get_first_value(whois_obj.get('registrant_name'))
        registrant['organization'] = self._get_first_value(whois_obj.get('org') or whois_obj.get('organization'))
        registrant['email'] = self._get_first_value(whois_obj.get('emails'))
        registrant['country'] = self._get_first_value(whois_obj.get('country'))
        
        data['registrant'] = registrant
        
        # Privacy protection
        data['privacy_protection'] = self._detect_privacy_protection(whois_obj)
        
        # Raw WHOIS data
        data['raw'] = str(whois_obj)
        
        return data
    
    def _get_whois_from_api(self, domain):
        """Get WHOIS information from WHOIS XML API"""
        if not self.api_key:
            return None
        
        try:
            url = f"https://www.whoisxmlapi.com/whoisserver/WhoisService"
            params = {
                "apiKey": self.api_key,
                "domainName": domain,
                "outputFormat": "JSON"
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            whois_record = data.get('WhoisRecord', {})
            
            result = {}
            
            # Extract basic information
            result['domain_name'] = whois_record.get('domainName')
            result['registrar'] = whois_record.get('registrarName')
            result['whois_server'] = whois_record.get('registrarWhoIsServer')
            
            # Extract dates
            created_date = whois_record.get('createdDate')
            updated_date = whois_record.get('updatedDate')
            expiration_date = whois_record.get('expiresDate')
            
            result['creation_date'] = created_date
            result['updated_date'] = updated_date
            result['expiration_date'] = expiration_date
            
            # Calculate age in days
            if created_date:
                try:
                    creation_date = datetime.datetime.strptime(created_date, "%Y-%m-%d")
                    age_days = (datetime.datetime.now() - creation_date).days
                    result['age_days'] = age_days
                except:
                    result['age_days'] = 0
            
            # Extract registrant information
            registrant = {}
            registrant_data = whois_record.get('registrant', {})
            
            registrant['name'] = registrant_data.get('name')
            registrant['organization'] = registrant_data.get('organization')
            registrant['email'] = registrant_data.get('email')
            registrant['country'] = registrant_data.get('country')
            
            result['registrant'] = registrant
            
            # Privacy protection
            result['privacy_protection'] = self._detect_api_privacy_protection(whois_record)
            
            return result
        
        except Exception as e:
            print(f"API error: {str(e)}")
            return None
    
    def _get_first_value(self, value):
        """Get the first value from a list or return the value itself"""
        if isinstance(value, list) and value:
            return value[0]
        return value
    
    def _format_date(self, date_value):
        """Format a date value as a string"""
        if not date_value:
            return None
        
        if isinstance(date_value, datetime.datetime):
            return date_value.strftime("%Y-%m-%d")
        
        return str(date_value)
    
    def _detect_privacy_protection(self, whois_obj):
        """Detect if privacy protection is enabled"""
        # Check for common privacy protection services
        privacy_services = [
            "REDACTED FOR PRIVACY",
            "PRIVACY",
            "PRIVATE",
            "REDACTED",
            "PROTECTED",
            "WITHHELD",
            "GDPR",
            "PERSONAL DATA",
            "PRIVACYGUARDIAN",
            "WHOISGUARD"
        ]
        
        # Check registrant information
        registrant_name = str(self._get_first_value(whois_obj.get('registrant_name') or "")).upper()
        registrant_org = str(self._get_first_value(whois_obj.get('org') or whois_obj.get('organization') or "")).upper()
        registrant_email = str(self._get_first_value(whois_obj.get('emails') or "")).upper()
        
        # Check if any privacy service keywords are in the registrant information
        for service in privacy_services:
            if (service in registrant_name or 
                service in registrant_org or 
                service in registrant_email):
                return True
        
        # Check for privacy service email domains
        privacy_email_domains = [
            "PRIVACY", "PROTECT", "PROXY", "WHOIS", "GUARD", "DOMAIN"
        ]
        
        if registrant_email:
            for domain in privacy_email_domains:
                if domain in registrant_email:
                    return True
        
        return False
    
    def _detect_api_privacy_protection(self, whois_record):
        """Detect if privacy protection is enabled from API response"""
        # Check if the API explicitly indicates privacy
        if whois_record.get('privacyProxy', False):
            return True
        
        # Check registrant information
        registrant = whois_record.get('registrant', {})
        registrant_name = str(registrant.get('name', "")).upper()
        registrant_org = str(registrant.get('organization', "")).upper()
        registrant_email = str(registrant.get('email', "")).upper()
        
        # Check for privacy keywords
        privacy_keywords = [
            "REDACTED FOR PRIVACY",
            "PRIVACY",
            "PRIVATE",
            "REDACTED",
            "PROTECTED",
            "WITHHELD",
            "GDPR",
            "PERSONAL DATA"
        ]
        
        for keyword in privacy_keywords:
            if (keyword in registrant_name or 
                keyword in registrant_org or 
                keyword in registrant_email):
                return True
        
        return False
