"""
DomainInsight - WHOIS Information View
Displays detailed WHOIS information for a domain
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QGroupBox, QGridLayout, QTextEdit)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class WhoisView(QWidget):
    """WHOIS information widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        layout = QVBoxLayout(self)
        
        # WHOIS header
        self.whois_header = QLabel("WHOIS Information")
        self.whois_header.setAlignment(Qt.AlignCenter)
        self.whois_header.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(self.whois_header)
        
        # Registration information
        reg_group = QGroupBox("Registration Information")
        reg_layout = QGridLayout()
        
        # Create labels for registration information
        row = 0
        
        reg_layout.addWidget(QLabel("Domain Name:"), row, 0)
        self.domain_name_label = QLabel("Unknown")
        reg_layout.addWidget(self.domain_name_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Registrar:"), row, 0)
        self.registrar_label = QLabel("Unknown")
        reg_layout.addWidget(self.registrar_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("WHOIS Server:"), row, 0)
        self.whois_server_label = QLabel("Unknown")
        reg_layout.addWidget(self.whois_server_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Creation Date:"), row, 0)
        self.creation_date_label = QLabel("Unknown")
        reg_layout.addWidget(self.creation_date_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Updated Date:"), row, 0)
        self.updated_date_label = QLabel("Unknown")
        reg_layout.addWidget(self.updated_date_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Expiration Date:"), row, 0)
        self.expiration_date_label = QLabel("Unknown")
        reg_layout.addWidget(self.expiration_date_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Status:"), row, 0)
        self.status_label = QLabel("Unknown")
        reg_layout.addWidget(self.status_label, row, 1)
        
        row += 1
        reg_layout.addWidget(QLabel("Privacy Protection:"), row, 0)
        self.privacy_label = QLabel("Unknown")
        reg_layout.addWidget(self.privacy_label, row, 1)
        
        reg_group.setLayout(reg_layout)
        layout.addWidget(reg_group)
        
        # Registrant information
        registrant_group = QGroupBox("Registrant Information")
        registrant_layout = QGridLayout()
        
        # Create labels for registrant information
        row = 0
        
        registrant_layout.addWidget(QLabel("Name:"), row, 0)
        self.registrant_name_label = QLabel("Unknown")
        registrant_layout.addWidget(self.registrant_name_label, row, 1)
        
        row += 1
        registrant_layout.addWidget(QLabel("Organization:"), row, 0)
        self.registrant_org_label = QLabel("Unknown")
        registrant_layout.addWidget(self.registrant_org_label, row, 1)
        
        row += 1
        registrant_layout.addWidget(QLabel("Email:"), row, 0)
        self.registrant_email_label = QLabel("Unknown")
        registrant_layout.addWidget(self.registrant_email_label, row, 1)
        
        row += 1
        registrant_layout.addWidget(QLabel("Country:"), row, 0)
        self.registrant_country_label = QLabel("Unknown")
        registrant_layout.addWidget(self.registrant_country_label, row, 1)
        
        registrant_group.setLayout(registrant_layout)
        layout.addWidget(registrant_group)
        
        # Raw WHOIS data
        raw_group = QGroupBox("Raw WHOIS Data")
        raw_layout = QVBoxLayout()
        
        self.raw_text = QTextEdit()
        self.raw_text.setReadOnly(True)
        self.raw_text.setFont(QFont("Courier New", 10))
        raw_layout.addWidget(self.raw_text)
        
        raw_group.setLayout(raw_layout)
        layout.addWidget(raw_group)
    
    def clear(self):
        """Clear the view"""
        self.domain_name_label.setText("Unknown")
        self.registrar_label.setText("Unknown")
        self.whois_server_label.setText("Unknown")
        self.creation_date_label.setText("Unknown")
        self.updated_date_label.setText("Unknown")
        self.expiration_date_label.setText("Unknown")
        self.status_label.setText("Unknown")
        self.privacy_label.setText("Unknown")
        
        self.registrant_name_label.setText("Unknown")
        self.registrant_org_label.setText("Unknown")
        self.registrant_email_label.setText("Unknown")
        self.registrant_country_label.setText("Unknown")
        
        self.raw_text.clear()
    
    def update_view(self, data):
        """Update the view with WHOIS data"""
        if not data:
            self.clear()
            return
        
        # Update registration information
        self.domain_name_label.setText(str(data.get('domain_name', 'Unknown')))
        self.registrar_label.setText(str(data.get('registrar', 'Unknown')))
        self.whois_server_label.setText(str(data.get('whois_server', 'Unknown')))
        self.creation_date_label.setText(str(data.get('creation_date', 'Unknown')))
        self.updated_date_label.setText(str(data.get('updated_date', 'Unknown')))
        self.expiration_date_label.setText(str(data.get('expiration_date', 'Unknown')))
        
        # Format status
        status = data.get('status', [])
        if isinstance(status, list):
            self.status_label.setText(", ".join(status))
        else:
            self.status_label.setText(str(status))
        
        # Privacy protection
        privacy = data.get('privacy_protection', None)
        if privacy is True:
            self.privacy_label.setText("Enabled")
        elif privacy is False:
            self.privacy_label.setText("Disabled")
        else:
            self.privacy_label.setText("Unknown")
        
        # Update registrant information
        registrant = data.get('registrant', {})
        self.registrant_name_label.setText(str(registrant.get('name', 'Unknown')))
        self.registrant_org_label.setText(str(registrant.get('organization', 'Unknown')))
        self.registrant_email_label.setText(str(registrant.get('email', 'Unknown')))
        self.registrant_country_label.setText(str(registrant.get('country', 'Unknown')))
        
        # Update raw WHOIS data
        raw_text = data.get('raw', '')
        if raw_text:
            self.raw_text.setText(raw_text)
        else:
            self.raw_text.setText("Raw WHOIS data not available")
