"""
DomainInsight - Domain Overview View
Displays summary information about a domain
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QGroupBox, QGridLayout, QProgressBar)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class DomainView(QWidget):
    """Domain overview widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        layout = QVBoxLayout(self)
        
        # Domain header
        self.domain_header = QLabel("No domain loaded")
        self.domain_header.setAlignment(Qt.AlignCenter)
        self.domain_header.setFont(QFont("Arial", 16, QFont.Bold))
        layout.addWidget(self.domain_header)
        
        # Security score
        score_group = QGroupBox("Security Score")
        score_layout = QVBoxLayout()
        
        self.score_bar = QProgressBar()
        self.score_bar.setRange(0, 100)
        self.score_bar.setValue(0)
        self.score_bar.setTextVisible(True)
        self.score_bar.setFormat("%v/100")
        score_layout.addWidget(self.score_bar)
        
        self.score_label = QLabel("No security assessment available")
        self.score_label.setAlignment(Qt.AlignCenter)
        score_layout.addWidget(self.score_label)
        
        score_group.setLayout(score_layout)
        layout.addWidget(score_group)
        
        # Summary information
        summary_group = QGroupBox("Domain Summary")
        summary_layout = QGridLayout()
        
        # Create labels for summary information
        row = 0
        
        summary_layout.addWidget(QLabel("Registrar:"), row, 0)
        self.registrar_label = QLabel("Unknown")
        summary_layout.addWidget(self.registrar_label, row, 1)
        
        row += 1
        summary_layout.addWidget(QLabel("Creation Date:"), row, 0)
        self.creation_date_label = QLabel("Unknown")
        summary_layout.addWidget(self.creation_date_label, row, 1)
        
        row += 1
        summary_layout.addWidget(QLabel("Expiration Date:"), row, 0)
        self.expiration_date_label = QLabel("Unknown")
        summary_layout.addWidget(self.expiration_date_label, row, 1)
        
        row += 1
        summary_layout.addWidget(QLabel("Domain Age:"), row, 0)
        self.age_label = QLabel("Unknown")
        summary_layout.addWidget(self.age_label, row, 1)
        
        row += 1
        summary_layout.addWidget(QLabel("IP Address:"), row, 0)
        self.ip_label = QLabel("Unknown")
        summary_layout.addWidget(self.ip_label, row, 1)
        
        row += 1
        summary_layout.addWidget(QLabel("Name Servers:"), row, 0)
        self.nameservers_label = QLabel("Unknown")
        summary_layout.addWidget(self.nameservers_label, row, 1)
        
        summary_group.setLayout(summary_layout)
        layout.addWidget(summary_group)
        
        # Issues and recommendations
        issues_group = QGroupBox("Issues & Recommendations")
        issues_layout = QVBoxLayout()
        
        self.issues_label = QLabel("No issues to display")
        issues_layout.addWidget(self.issues_label)
        
        issues_group.setLayout(issues_layout)
        layout.addWidget(issues_group)
        
        # Add stretch to push everything to the top
        layout.addStretch()
    
    def clear(self):
        """Clear the view"""
        self.domain_header.setText("No domain loaded")
        self.score_bar.setValue(0)
        self.score_label.setText("No security assessment available")
        self.registrar_label.setText("Unknown")
        self.creation_date_label.setText("Unknown")
        self.expiration_date_label.setText("Unknown")
        self.age_label.setText("Unknown")
        self.ip_label.setText("Unknown")
        self.nameservers_label.setText("Unknown")
        self.issues_label.setText("No issues to display")
    
    def update_view(self, data):
        """Update the view with domain data"""
        if not data:
            self.clear()
            return
        
        # Update domain header
        self.domain_header.setText(data.get('domain', 'Unknown Domain'))
        
        # Update security score
        security_score = data.get('security_score', {})
        score = security_score.get('score', 0)
        self.score_bar.setValue(score)
        
        # Set color based on score
        if score >= 80:
            self.score_bar.setStyleSheet("QProgressBar::chunk { background-color: green; }")
        elif score >= 60:
            self.score_bar.setStyleSheet("QProgressBar::chunk { background-color: yellow; }")
        else:
            self.score_bar.setStyleSheet("QProgressBar::chunk { background-color: red; }")
        
        # Update score label
        if score >= 80:
            self.score_label.setText("Good - This domain appears to be secure")
        elif score >= 60:
            self.score_label.setText("Fair - This domain has some security concerns")
        else:
            self.score_label.setText("Poor - This domain has significant security issues")
        
        # Update summary information
        summary = data.get('summary', {})
        
        self.registrar_label.setText(summary.get('registrar', 'Unknown'))
        self.creation_date_label.setText(str(summary.get('creation_date', 'Unknown')))
        self.expiration_date_label.setText(str(summary.get('expiration_date', 'Unknown')))
        
        age_days = summary.get('age_days', 0)
        if age_days > 0:
            years = age_days // 365
            days = age_days % 365
            if years > 0:
                self.age_label.setText(f"{years} years, {days} days")
            else:
                self.age_label.setText(f"{days} days")
        else:
            self.age_label.setText("Unknown")
        
        self.ip_label.setText(summary.get('ip_address', 'Unknown'))
        
        nameservers = summary.get('nameservers', 0)
        self.nameservers_label.setText(str(nameservers) if nameservers else "Unknown")
        
        # Update issues and recommendations
        issues = security_score.get('reasons', [])
        if issues:
            issues_text = "<ul>"
            for issue in issues:
                issues_text += f"<li>{issue}</li>"
            issues_text += "</ul>"
            self.issues_label.setText(issues_text)
        else:
            self.issues_label.setText("No issues detected")
