"""
DomainInsight - Main Window
The primary GUI container for the application
"""

import os
from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QAction, QFileDialog, 
                           QMessageBox, QToolBar, QStatusBar, QLineEdit,
                           QVBoxLayout, QHBoxLayout, QWidget, QPushButton,
                           QLabel, QComboBox, QProgressBar, QDialog)
from PyQt5.QtCore import Qt, QSize, QThread, pyqtSignal
from PyQt5.QtGui import QIcon

from .domain_view import DomainView
from .whois_view import WhoisView
from .dns_view import DNSView
from .history_view import HistoryView
from .related_view import RelatedView

from ..core.domain_analyzer import DomainAnalyzer
from ..utils.validators import is_valid_domain

class AnalysisThread(QThread):
    """Thread for domain analysis"""
    analysis_complete = pyqtSignal(dict)
    progress_update = pyqtSignal(int, str)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, domain):
        super().__init__()
        self.domain = domain
        self.analyzer = DomainAnalyzer()
    
    def run(self):
        """Run the analysis"""
        try:
            # Update progress
            self.progress_update.emit(10, "Starting domain analysis...")
            
            # Analyze domain
            results = self.analyzer.analyze_domain(
                self.domain, 
                progress_callback=self.progress_update
            )
            
            # Emit results
            self.analysis_complete.emit(results)
            
        except Exception as e:
            self.error_occurred.emit(str(e))

class MainWindow(QMainWindow):
    """Main application window"""
    
    def __init__(self):
        super().__init__()
        
        self.domain_results = None
        self.analysis_thread = None
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Set window properties
        self.setWindowTitle("DomainInsight - Domain Analysis Tool")
        self.setMinimumSize(1000, 700)
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create status bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.status_bar.showMessage("Ready")
        
        # Create progress bar in status bar (hidden by default)
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setFixedWidth(200)
        self.progress_bar.setVisible(False)
        self.status_bar.addPermanentWidget(self.progress_bar)
        
        # Create central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Create search area
        search_layout = QHBoxLayout()
        
        search_layout.addWidget(QLabel("Domain:"))
        
        self.domain_input = QLineEdit()
        self.domain_input.setPlaceholderText("Enter domain name (e.g., example.com)")
        self.domain_input.returnPressed.connect(self.on_analyze_clicked)
        search_layout.addWidget(self.domain_input, 1)
        
        self.analyze_button = QPushButton("Analyze")
        self.analyze_button.clicked.connect(self.on_analyze_clicked)
        search_layout.addWidget(self.analyze_button)
        
        main_layout.addLayout(search_layout)
        
        # Create tab widget
        self.tabs = QTabWidget()
        
        # Create and add tabs
        self.domain_view = DomainView()
        self.whois_view = WhoisView()
        self.dns_view = DNSView()
        self.history_view = HistoryView()
        self.related_view = RelatedView()
        
        self.tabs.addTab(self.domain_view, "Overview")
        self.tabs.addTab(self.whois_view, "WHOIS")
        self.tabs.addTab(self.dns_view, "DNS Records")
        self.tabs.addTab(self.history_view, "History")
        self.tabs.addTab(self.related_view, "Related Domains")
        
        main_layout.addWidget(self.tabs)
    
    def create_menu_bar(self):
        """Create the application menu bar"""
        menu_bar = self.menuBar()
        
        # File menu
        file_menu = menu_bar.addMenu("&File")
        
        new_analysis_action = QAction("&New Analysis", self)
        new_analysis_action.setShortcut("Ctrl+N")
        new_analysis_action.triggered.connect(self.new_analysis)
        file_menu.addAction(new_analysis_action)
        
        file_menu.addSeparator()
        
        export_menu = file_menu.addMenu("Export")
        
        export_pdf_action = QAction("Export as PDF...", self)
        export_pdf_action.triggered.connect(lambda: self.export_results("pdf"))
        export_menu.addAction(export_pdf_action)
        
        export_html_action = QAction("Export as HTML...", self)
        export_html_action.triggered.connect(lambda: self.export_results("html"))
        export_menu.addAction(export_html_action)
        
        export_json_action = QAction("Export as JSON...", self)
        export_json_action.triggered.connect(lambda: self.export_results("json"))
        export_menu.addAction(export_json_action)
        
        export_csv_action = QAction("Export as CSV...", self)
        export_csv_action.triggered.connect(lambda: self.export_results("csv"))
        export_menu.addAction(export_csv_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Tools menu
        tools_menu = menu_bar.addMenu("&Tools")
        
        batch_analysis_action = QAction("Batch Analysis...", self)
        batch_analysis_action.triggered.connect(self.show_batch_analysis)
        tools_menu.addAction(batch_analysis_action)
        
        tools_menu.addSeparator()
        
        settings_action = QAction("Settings...", self)
        settings_action.triggered.connect(self.show_settings)
        tools_menu.addAction(settings_action)
        
        # Help menu
        help_menu = menu_bar.addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
    
    def create_toolbar(self):
        """Create the main toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Add actions
        new_analysis_action = QAction("New Analysis", self)
        new_analysis_action.triggered.connect(self.new_analysis)
        toolbar.addAction(new_analysis_action)
        
        toolbar.addSeparator()
        
        export_action = QAction("Export Results", self)
        export_action.triggered.connect(self.export_results)
        toolbar.addAction(export_action)
    
    def on_analyze_clicked(self):
        """Handle analyze button click"""
        domain = self.domain_input.text().strip().lower()
        
        if not domain:
            QMessageBox.warning(self, "Input Error", "Please enter a domain name.")
            return
        
        if not is_valid_domain(domain):
            QMessageBox.warning(self, "Input Error", "Please enter a valid domain name.")
            return
        
        self.analyze_domain(domain)
    
    def analyze_domain(self, domain):
        """Analyze the specified domain"""
        # Update UI
        self.domain_input.setText(domain)
        self.status_bar.showMessage(f"Analyzing domain: {domain}")
        self.progress_bar.setValue(0)
        self.progress_bar.setVisible(True)
        self.analyze_button.setEnabled(False)
        
        # Clear previous results
        self.domain_view.clear()
        self.whois_view.clear()
        self.dns_view.clear()
        self.history_view.clear()
        self.related_view.clear()
        
        # Start analysis thread
        self.analysis_thread = AnalysisThread(domain)
        self.analysis_thread.analysis_complete.connect(self.on_analysis_complete)
        self.analysis_thread.progress_update.connect(self.on_progress_update)
        self.analysis_thread.error_occurred.connect(self.on_analysis_error)
        self.analysis_thread.start()
    
    def on_analysis_complete(self, results):
        """Handle analysis completion"""
        # Store results
        self.domain_results = results
        
        # Update views
        self.domain_view.update_view(results)
        self.whois_view.update_view(results.get('whois', {}))
        self.dns_view.update_view(results.get('dns', {}))
        self.history_view.update_view(results.get('history', {}))
        self.related_view.update_view(results.get('related', {}))
        
        # Update UI
        self.progress_bar.setVisible(False)
        self.status_bar.showMessage(f"Analysis complete for {results['domain']}")
        self.analyze_button.setEnabled(True)
    
    def on_progress_update(self, progress, message):
        """Handle progress updates"""
        self.progress_bar.setValue(progress)
        self.status_bar.showMessage(message)
    
    def on_analysis_error(self, error_message):
        """Handle analysis errors"""
        # Update UI
        self.progress_bar.setVisible(False)
        self.status_bar.showMessage("Analysis failed")
        self.analyze_button.setEnabled(True)
        
        # Show error message
        QMessageBox.critical(self, "Analysis Error", f"Error analyzing domain: {error_message}")
    
    def new_analysis(self):
        """Start a new analysis"""
        self.domain_input.clear()
        self.domain_results = None
        
        # Clear views
        self.domain_view.clear()
        self.whois_view.clear()
        self.dns_view.clear()
        self.history_view.clear()
        self.related_view.clear()
        
        # Update UI
        self.status_bar.showMessage("Ready")
    
    def export_results(self, format_type=None):
        """Export analysis results"""
        if not self.domain_results:
            QMessageBox.warning(self, "No Data", "Please analyze a domain first.")
            return
        
        if not format_type:
            # Show dialog to select format
            formats = ["pdf", "html", "json", "csv"]
            format_dialog = QDialog(self)
            format_dialog.setWindowTitle("Export Format")
            format_layout = QVBoxLayout(format_dialog)
            
            format_layout.addWidget(QLabel("Select export format:"))
            
            format_combo = QComboBox()
            format_combo.addItems(formats)
            format_layout.addWidget(format_combo)
            
            button_layout = QHBoxLayout()
            cancel_button = QPushButton("Cancel")
            cancel_button.clicked.connect(format_dialog.reject)
            button_layout.addWidget(cancel_button)
            
            ok_button = QPushButton("OK")
            ok_button.clicked.connect(format_dialog.accept)
            button_layout.addWidget(ok_button)
            
            format_layout.addLayout(button_layout)
            
            if format_dialog.exec_():
                format_type = format_combo.currentText()
            else:
                return
        
        # Get file path
        default_name = f"{self.domain_results['domain']}_analysis.{format_type}"
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Results", default_name, 
            f"{format_type.upper()} Files (*.{format_type})"
        )
        
        if not file_path:
            return
        
        try:
            # Export data
            from ..utils.data_export import export_data
            export_data(self.domain_results, file_path, format_type)
            
            self.status_bar.showMessage(f"Results exported to {file_path}")
            
            # Ask if user wants to open the file
            if format_type in ['pdf', 'html']:
                reply = QMessageBox.question(
                    self, "Open File", 
                    "Export complete. Would you like to open the file?",
                    QMessageBox.Yes | QMessageBox.No, QMessageBox.No
                )
                
                if reply == QMessageBox.Yes:
                    import webbrowser
                    webbrowser.open(file_path)
                    
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Error exporting results: {str(e)}")
    
    def show_batch_analysis(self):
        """Show batch analysis dialog"""
        QMessageBox.information(self, "Batch Analysis", "Batch analysis feature will be implemented in a future version.")
    
    def show_settings(self):
        """Show settings dialog"""
        QMessageBox.information(self, "Settings", "Settings dialog will be implemented in a future version.")
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self,
            "About DomainInsight",
            "DomainInsight v1.0\n\n"
            "A comprehensive domain analysis tool that aggregates WHOIS information, "
            "hosting history, DNS records, and related domains.\n\n"
            "Created for security professionals, researchers, and IT administrators."
        )
