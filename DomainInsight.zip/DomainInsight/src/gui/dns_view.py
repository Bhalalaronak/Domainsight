"""
DomainInsight - DNS Records View
Displays DNS records for a domain
"""

from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QGroupBox, QTableWidget, QTableWidgetItem,
                           QHeaderView, QTabWidget)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QColor

class DNSView(QWidget):
    """DNS records widget"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        layout = QVBoxLayout(self)
        
        # DNS header
        self.dns_header = QLabel("DNS Records")
        self.dns_header.setAlignment(Qt.AlignCenter)
        self.dns_header.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(self.dns_header)
        
        # Create tab widget for different record types
        self.tabs = QTabWidget()
        
        # A/AAAA Records
        self.a_records_tab = QWidget()
        a_layout = QVBoxLayout(self.a_records_tab)
        
        self.a_table = QTableWidget(0, 3)
        self.a_table.setHorizontalHeaderLabels(["Type", "Name", "Value"])
        self.a_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        a_layout.addWidget(self.a_table)
        
        self.tabs.addTab(self.a_records_tab, "A/AAAA Records")
        
        # MX Records
        self.mx_records_tab = QWidget()
        mx_layout = QVBoxLayout(self.mx_records_tab)
        
        self.mx_table = QTableWidget(0, 3)
        self.mx_table.setHorizontalHeaderLabels(["Priority", "Host", "Value"])
        self.mx_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        mx_layout.addWidget(self.mx_table)
        
        self.tabs.addTab(self.mx_records_tab, "MX Records")
        
        # NS Records
        self.ns_records_tab = QWidget()
        ns_layout = QVBoxLayout(self.ns_records_tab)
        
        self.ns_table = QTableWidget(0, 2)
        self.ns_table.setHorizontalHeaderLabels(["Name", "Value"])
        self.ns_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        ns_layout.addWidget(self.ns_table)
        
        self.tabs.addTab(self.ns_records_tab, "NS Records")
        
        # TXT Records
        self.txt_records_tab = QWidget()
        txt_layout = QVBoxLayout(self.txt_records_tab)
        
        self.txt_table = QTableWidget(0, 2)
        self.txt_table.setHorizontalHeaderLabels(["Name", "Value"])
        self.txt_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        txt_layout.addWidget(self.txt_table)
        
        self.tabs.addTab(self.txt_records_tab, "TXT Records")
        
        # CNAME Records
        self.cname_records_tab = QWidget()
        cname_layout = QVBoxLayout(self.cname_records_tab)
        
        self.cname_table = QTableWidget(0, 2)
        self.cname_table.setHorizontalHeaderLabels(["Name", "Value"])
        self.cname_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        cname_layout.addWidget(self.cname_table)
        
        self.tabs.addTab(self.cname_records_tab, "CNAME Records")
        
        # SOA Record
        self.soa_record_tab = QWidget()
        soa_layout = QVBoxLayout(self.soa_record_tab)
        
        self.soa_table = QTableWidget(0, 2)
        self.soa_table.setHorizontalHeaderLabels(["Field", "Value"])
        self.soa_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        soa_layout.addWidget(self.soa_table)
        
        self.tabs.addTab(self.soa_record_tab, "SOA Record")
        
        # Other Records
        self.other_records_tab = QWidget()
        other_layout = QVBoxLayout(self.other_records_tab)
        
        self.other_table = QTableWidget(0, 3)
        self.other_table.setHorizontalHeaderLabels(["Type", "Name", "Value"])
        self.other_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        other_layout.addWidget(self.other_table)
        
        self.tabs.addTab(self.other_records_tab, "Other Records")
        
        layout.addWidget(self.tabs)
        
        # DNS Security
        security_group = QGroupBox("DNS Security")
        security_layout = QVBoxLayout()
        
        self.security_table = QTableWidget(0, 2)
        self.security_table.setHorizontalHeaderLabels(["Feature", "Status"])
        self.security_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        security_layout.addWidget(self.security_table)
        
        security_group.setLayout(security_layout)
        layout.addWidget(security_group)
    
    def clear(self):
        """Clear the view"""
        self.a_table.setRowCount(0)
        self.mx_table.setRowCount(0)
        self.ns_table.setRowCount(0)
        self.txt_table.setRowCount(0)
        self.cname_table.setRowCount(0)
        self.soa_table.setRowCount(0)
        self.other_table.setRowCount(0)
        self.security_table.setRowCount(0)
    
    def update_view(self, data):
        """Update the view with DNS data"""
        if not data:
            self.clear()
            return
        
        # Update A/AAAA records
        self.a_table.setRowCount(0)
        
        a_records = data.get('a', [])
        aaaa_records = data.get('aaaa', [])
        
        for record in a_records:
            row = self.a_table.rowCount()
            self.a_table.insertRow(row)
            self.a_table.setItem(row, 0, QTableWidgetItem("A"))
            self.a_table.setItem(row, 1, QTableWidgetItem(data.get('domain', '')))
            self.a_table.setItem(row, 2, QTableWidgetItem(record))
        
        for record in aaaa_records:
            row = self.a_table.rowCount()
            self.a_table.insertRow(row)
            self.a_table.setItem(row, 0, QTableWidgetItem("AAAA"))
            self.a_table.setItem(row, 1, QTableWidgetItem(data.get('domain', '')))
            self.a_table.setItem(row, 2, QTableWidgetItem(record))
        
        # Update MX records
        self.mx_table.setRowCount(0)
        
        mx_records = data.get('mx', [])
        for record in mx_records:
            row = self.mx_table.rowCount()
            self.mx_table.insertRow(row)
            
            if isinstance(record, dict):
                self.mx_table.setItem(row, 0, QTableWidgetItem(str(record.get('priority', ''))))
                self.mx_table.setItem(row, 1, QTableWidgetItem(data.get('domain', '')))
                self.mx_table.setItem(row, 2, QTableWidgetItem(record.get('host', '')))
            else:
                self.mx_table.setItem(row, 0, QTableWidgetItem(""))
                self.mx_table.setItem(row, 1, QTableWidgetItem(data.get('domain', '')))
                self.mx_table.setItem(row, 2, QTableWidgetItem(str(record)))
        
        # Update NS records
        self.ns_table.setRowCount(0)
        
        ns_records = data.get('ns', [])
        for record in ns_records:
            row = self.ns_table.rowCount()
            self.ns_table.insertRow(row)
            self.ns_table.setItem(row, 0, QTableWidgetItem(data.get('domain', '')))
            self.ns_table.setItem(row, 1, QTableWidgetItem(record))
        
        # Update TXT records
        self.txt_table.setRowCount(0)
        
        txt_records = data.get('txt', [])
        for record in txt_records:
            row = self.txt_table.rowCount()
            self.txt_table.insertRow(row)
            self.txt_table.setItem(row, 0, QTableWidgetItem(data.get('domain', '')))
            self.txt_table.setItem(row, 1, QTableWidgetItem(record))
        
        # Update CNAME records
        self.cname_table.setRowCount(0)
        
        cname_records = data.get('cname', [])
        for record in cname_records:
            row = self.cname_table.rowCount()
            self.cname_table.insertRow(row)
            self.cname_table.setItem(row, 0, QTableWidgetItem(data.get('domain', '')))
            self.cname_table.setItem(row, 1, QTableWidgetItem(record))
        
        # Update SOA record
        self.soa_table.setRowCount(0)
        
        soa_record = data.get('soa', {})
        if soa_record:
            for field, value in soa_record.items():
                row = self.soa_table.rowCount()
                self.soa_table.insertRow(row)
                self.soa_table.setItem(row, 0, QTableWidgetItem(field))
                self.soa_table.setItem(row, 1, QTableWidgetItem(str(value)))
        
        # Update security features
        self.security_table.setRowCount(0)
        
        # DNSSEC
        row = self.security_table.rowCount()
        self.security_table.insertRow(row)
        self.security_table.setItem(row, 0, QTableWidgetItem("DNSSEC"))
        
        dnssec_status = "Enabled" if data.get('dnssec', False) else "Disabled"
        status_item = QTableWidgetItem(dnssec_status)
        if dnssec_status == "Enabled":
            status_item.setBackground(QColor(200, 255, 200))  # Light green
        else:
            status_item.setBackground(QColor(255, 200, 200))  # Light red
        
        self.security_table.setItem(row, 1, status_item)
        
        # SPF
        row = self.security_table.rowCount()
        self.security_table.insertRow(row)
        self.security_table.setItem(row, 0, QTableWidgetItem("SPF Record"))
        
        spf_status = "Present" if data.get('has_spf', False) else "Missing"
        status_item = QTableWidgetItem(spf_status)
        if spf_status == "Present":
            status_item.setBackground(QColor(200, 255, 200))  # Light green
        else:
            status_item.setBackground(QColor(255, 200, 200))  # Light red
        
        self.security_table.setItem(row, 1, status_item)
        
        # DMARC
        row = self.security_table.rowCount()
        self.security_table.insertRow(row)
        self.security_table.setItem(row, 0, QTableWidgetItem("DMARC Record"))
        
        dmarc_status = "Present" if data.get('has_dmarc', False) else "Missing"
        status_item = QTableWidgetItem(dmarc_status)
        if dmarc_status == "Present":
            status_item.setBackground(QColor(200, 255, 200))  # Light green
        else:
            status_item.setBackground(QColor(255, 200, 200))  # Light red
        
        self.security_table.setItem(row, 1, status_item)
