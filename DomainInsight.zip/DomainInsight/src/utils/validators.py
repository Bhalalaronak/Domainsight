"""
DomainInsight - Validators
Input validation utilities
"""

import re
import validators

def is_valid_domain(domain):
    """
    Validate if a string is a valid domain name
    
    Args:
        domain (str): The domain name to validate
    
    Returns:
        bool: True if valid, False otherwise
    """
    # Use validators library for basic validation
    if validators.domain(domain):
        return True
    
    # Additional validation for edge cases
    domain_pattern = r'^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$'
    return bool(re.match(domain_pattern, domain))

def is_valid_ip(ip):
    """
    Validate if a string is a valid IP address
    
    Args:
        ip (str): The IP address to validate
    
    Returns:
        bool: True if valid, False otherwise
    """
    return validators.ipv4(ip) or validators.ipv6(ip)

def is_valid_email(email):
    """
    Validate if a string is a valid email address
    
    Args:
        email (str): The email address to validate
    
    Returns:
        bool: True if valid, False otherwise
    """
    return validators.email(email)

def is_valid_url(url):
    """
    Validate if a string is a valid URL
    
    Args:
        url (str): The URL to validate
    
    Returns:
        bool: True if valid, False otherwise
    """
    return validators.url(url)

def sanitize_input(input_str):
    """
    Sanitize input string to prevent injection attacks
    
    Args:
        input_str (str): The input string to sanitize
    
    Returns:
        str: Sanitized string
    """
    # Remove potentially dangerous characters
    sanitized = re.sub(r'[;<>&|]', '', input_str)
    return sanitized.strip()

def normalize_domain(domain):
    """
    Normalize a domain name (lowercase, remove trailing dot)
    
    Args:
        domain (str): The domain name to normalize
    
    Returns:
        str: Normalized domain name
    """
    # Convert to lowercase
    domain = domain.lower()
    
    # Remove trailing dot if present
    if domain.endswith('.'):
        domain = domain[:-1]
    
    # Remove protocol and path if present
    domain = re.sub(r'^https?://', '', domain)
    domain = domain.split('/')[0]
    
    return domain
