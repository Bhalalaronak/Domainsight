# DomainInsight

![DomainInsight Logo](https://github.com/username/DomainInsight/raw/main/resources/logo.png)

A comprehensive domain analysis tool that aggregates WHOIS information, hosting history, DNS records, and related domains.

## Overview

DomainInsight is a powerful tool designed for cybersecurity professionals, researchers, and IT administrators to gather and analyze comprehensive information about domains. By consolidating data from multiple sources, it provides a complete picture of a domain's infrastructure, ownership, and history.

## Features

- **WHOIS Information**
  - Registrar details
  - Creation, expiration, and update dates
  - Registrant information (when available)
  - Privacy protection status

- **DNS Records Analysis**
  - A, AAAA, MX, NS, TXT, CNAME records
  - SOA record details
  - DNS health check
  - SPF and DMARC validation

- **Hosting History**
  - IP address history
  - Hosting provider changes
  - Geographic location tracking
  - ASN information

- **Related Domains**
  - Same-owner domains
  - Subdomain enumeration
  - Typosquatting detection
  - Similar domain discovery

- **Visualization & Reporting**
  - Interactive timeline of changes
  - Relationship graphs
  - Comprehensive PDF reports
  - CSV/JSON data export

## Screenshots

![Main Interface](https://github.com/username/DomainInsight/raw/main/resources/screenshot_main.png)
![DNS Analysis](https://github.com/username/DomainInsight/raw/main/resources/screenshot_dns.png)
![Domain Relationships](https://github.com/username/DomainInsight/raw/main/resources/screenshot_relationships.png)

## Installation

### Prerequisites

- Python 3.8 or higher
- pip (Python package manager)

### Setup

1. Clone the repository:
```bash
git clone https://github.com/username/DomainInsight.git
cd DomainInsight
```

2. Install the required dependencies:
```bash
pip install -r requirements.txt
```

3. Run the application:
```bash
python main.py
```

## Usage

1. Enter a domain name in the search bar
2. Click "Analyze" to start the domain analysis
3. Navigate through the tabs to view different aspects of the domain:
   - Overview: Summary of key information
   - WHOIS: Detailed registration information
   - DNS: Complete DNS records
   - History: Hosting and ownership history
   - Related: Connected and similar domains
4. Export the results using the Export button in various formats

## API Keys

Some features require API keys from third-party services:

1. Create a `.env` file in the project root directory
2. Add your API keys in the following format:
```
WHOISXMLAPI_KEY=your_key_here
SECURITYTRAILS_KEY=your_key_here
VIRUSTOTAL_KEY=your_key_here
```

## Ethical Usage

DomainInsight is designed for legitimate security research, IT administration, and educational purposes. Please use this tool responsibly and respect privacy and legal restrictions when gathering domain information.

## Contributing

Contributions to DomainInsight are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- This tool uses various public APIs and services for data collection
- Special thanks to the open-source community for libraries and tools that made this project possible
