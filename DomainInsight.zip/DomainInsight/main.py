#!/usr/bin/env python3
"""
DomainInsight - Domain Analysis Tool
Main application entry point
"""

import sys
import os
import argparse
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from src.gui.main_window import MainWindow
from dotenv import load_dotenv

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description='DomainInsight - Domain Analysis Tool')
    parser.add_argument('-d', '--domain', help='Domain to analyze')
    parser.add_argument('-o', '--output', help='Output file for report')
    parser.add_argument('-f', '--format', choices=['pdf', 'html', 'json', 'csv'], 
                      default='pdf', help='Output format for report')
    parser.add_argument('--cli', action='store_true', help='Run in command-line mode')
    return parser.parse_args()

def setup_environment():
    """Set up the application environment"""
    # Load environment variables from .env file
    load_dotenv()
    
    # Create data directories if they don't exist
    os.makedirs(os.path.join(os.path.dirname(__file__), 'data', 'reports'), exist_ok=True)

def run_cli_mode(args):
    """Run the application in command-line mode"""
    from src.core.domain_analyzer import DomainAnalyzer
    
    if not args.domain:
        print("Error: Domain name is required in CLI mode")
        return 1
    
    print(f"Analyzing domain: {args.domain}")
    
    analyzer = DomainAnalyzer()
    results = analyzer.analyze_domain(args.domain)
    
    if args.output:
        from src.utils.data_export import export_data
        export_data(results, args.output, args.format)
        print(f"Report saved to: {args.output}")
    else:
        # Print summary to console
        print("\nDomain Analysis Summary:")
        print(f"Domain: {results['domain']}")
        print(f"Registrar: {results.get('whois', {}).get('registrar', 'Unknown')}")
        print(f"Creation Date: {results.get('whois', {}).get('creation_date', 'Unknown')}")
        print(f"Expiration Date: {results.get('whois', {}).get('expiration_date', 'Unknown')}")
        print(f"Name Servers: {', '.join(results.get('dns', {}).get('ns', []))}")
        print(f"IP Address: {results.get('dns', {}).get('a', ['Unknown'])[0]}")
    
    return 0

def run_gui_mode(args):
    """Run the application in GUI mode"""
    # Enable high DPI scaling
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    app = QApplication(sys.argv)
    app.setApplicationName("DomainInsight")
    app.setOrganizationName("Security Tools")
    
    # Create and show the main window
    main_window = MainWindow()
    
    # If domain is specified, analyze it
    if args.domain:
        main_window.analyze_domain(args.domain)
    
    main_window.show()
    
    # Start the application event loop
    return app.exec_()

def main():
    """Main application entry point"""
    # Parse command line arguments
    args = parse_arguments()
    
    # Set up the application environment
    setup_environment()
    
    # Run in appropriate mode
    if args.cli:
        return run_cli_mode(args)
    else:
        return run_gui_mode(args)

if __name__ == "__main__":
    sys.exit(main())
